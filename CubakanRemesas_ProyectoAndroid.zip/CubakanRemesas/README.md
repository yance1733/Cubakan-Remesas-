# Cubakan Remesas — proyecto Android inicial

Este proyecto genera una app Android de demostración con una calculadora BRL → CUP. **No es todavía un servicio real de remesas**: la tasa 987 CUP/BRL es de ejemplo y no hay integración con Pix, proveedores de criptomonedas, bancos ni pagadores en Cuba.

## Crear el APK desde GitHub (se puede hacer desde el teléfono)
1. Inicia sesión o crea una cuenta en https://github.com.
2. Crea un repositorio nuevo llamado `CubakanRemesas` y déjalo público o privado.
3. Sube todos los archivos y carpetas de este proyecto, manteniendo la estructura, a la raíz del repositorio. Es importante que también se suba la carpeta oculta `.github/workflows`.
4. Abre la pestaña **Actions** del repositorio. Si GitHub pide habilitar workflows, acéptalo.
5. Selecciona **Construir APK de Cubakan Remesas** y pulsa **Run workflow** (si no aparece, primero sube los archivos a la rama `main`).
6. Espera a que la ejecución termine con marca verde. Entra en esa ejecución y busca **Artifacts**; descarga `CubakanRemesas-debug-apk`.
7. Descomprime el ZIP descargado en el teléfono. Abre `app-debug.apk` y, si Android lo solicita, permite instalar aplicaciones desde esa fuente. Instálala.

## Si usas un ordenador con Android SDK
Desde la raíz del proyecto ejecuta `gradle assembleDebug`. El APK se genera en `app/build/outputs/apk/debug/app-debug.apk`.

## Antes de usar con dinero real
Hace falta diseñar y probar el backend, integrar un proveedor de pagos autorizado, verificar las obligaciones legales de remesas en Brasil y Cuba, gestionar datos personales de forma segura y sustituir la tasa de demostración por una tasa fiable. No pongas claves API ni contraseñas en el código ni en GitHub.
