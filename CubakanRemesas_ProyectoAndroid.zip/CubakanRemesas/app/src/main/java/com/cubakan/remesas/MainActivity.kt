package com.cubakan.remesas

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.text.InputType
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private val navy = Color.rgb(15, 43, 82)
    private val blue = Color.rgb(26, 99, 191)
    private val pale = Color.rgb(239, 246, 255)
    private var amountField: EditText? = null
    private var resultText: TextView? = null
    private val demoRate = 987.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(248, 250, 253))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 26)
            setBackgroundColor(navy)
        }
        header.addView(text("Cubakan Remesas", 27f, Color.WHITE, true))
        header.addView(text("Conectando familias, estés donde estés", 14f, Color.rgb(218, 231, 250), false).apply { setPadding(0, 7, 0, 0) })
        root.addView(header)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 24)
        }
        content.addView(text("Envía de Brasil a Cuba", 21f, navy, true))
        content.addView(text("Calcula una estimación de tu remesa", 14f, Color.DKGRAY, false).apply { setPadding(0, 5, 0, 18) })

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.WHITE)
            elevation = 4f
        }
        card.addView(text("Tú envías (BRL)", 14f, navy, true))
        amountField = EditText(this).apply {
            hint = "Ej.: 50,00"
            setText("50")
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize = 22f
            setTextColor(navy)
            setPadding(10, 8, 10, 8)
        }
        card.addView(amountField, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val rateLabel = text("Tasa de demostración: 1 BRL = 987 CUP", 13f, Color.rgb(90, 100, 115), false)
        rateLabel.setPadding(0, 8, 0, 14)
        card.addView(rateLabel)
        val calc = Button(this).apply {
            text = "Calcular remesa"
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue))
            setOnClickListener { calculate() }
        }
        card.addView(calc, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        resultText = text("La persona recibe aproximadamente\n49.350 CUP", 20f, navy, true).apply {
            gravity = Gravity.CENTER
            setPadding(12, 20, 12, 20)
            setBackgroundColor(pale)
        }
        val resultParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        resultParams.topMargin = 16
        card.addView(resultText, resultParams)
        content.addView(card)

        val notice = text("IMPORTANTE\nEsta versión es una DEMO. La tasa es ficticia/de prueba y la app todavía no recibe Pix ni entrega CUP. No envíes dinero ni datos bancarios usando esta versión.", 13f, Color.rgb(120, 70, 20), false).apply {
            setPadding(14, 14, 14, 14)
            setBackgroundColor(Color.rgb(255, 245, 225))
        }
        val noticeParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        noticeParams.topMargin = 18
        content.addView(notice, noticeParams)
        content.addView(text("Próximo paso: conectar un proveedor de pagos autorizado y el sistema de pagos en Cuba.", 13f, Color.DKGRAY, false).apply { setPadding(2, 18, 2, 0) })

        val scroll = ScrollView(this)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun calculate() {
        val raw = amountField?.text?.toString()?.trim()?.replace(',', '.') ?: ""
        val amount = raw.toDoubleOrNull()
        if (amount == null || amount <= 0 || amount > 1000000) {
            Toast.makeText(this, "Escribe un importe válido en reales", Toast.LENGTH_SHORT).show()
            return
        }
        val cup = amount * demoRate
        val formatted = NumberFormat.getNumberInstance(Locale("es", "CU")).format(cup)
        resultText?.text = "La persona recibe aproximadamente\n$formatted CUP"
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
}
